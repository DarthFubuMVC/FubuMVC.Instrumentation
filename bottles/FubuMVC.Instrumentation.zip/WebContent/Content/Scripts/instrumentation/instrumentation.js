$(function() {
  $.gridwrapper.initGrid('#instrumentation-explorer',{
    sortname: 'Route',
    sortorder: 'asc',
    caption: 'Routes'
  });
});